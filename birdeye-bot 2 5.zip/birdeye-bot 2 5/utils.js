const { getTokenSecurityInfo } = require('./birdeyeApi');

const filterTokensBySecurity = async (tokens) => {
    const secureTokens = [];

    for (const token of tokens) {
        const securityInfo = await getTokenSecurityInfo(token.address);
        if (securityInfo) {
            // Add additional security checks if necessary
            console.log(`Token ${token.symbol} passed security checks.`);
            secureTokens.push(token);
        } else {
            console.log(`Token ${token.symbol} failed security checks.`);
        }
    }

    return secureTokens;
};

module.exports = { filterTokensBySecurity };
