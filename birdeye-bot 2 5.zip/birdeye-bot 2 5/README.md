# Sniping Bot

## Setup
1. Install Node.js.
2. Clone the repository and navigate to the folder.
3. Install the dependencies:
   ```bash
   npm install
