const axios = require('axios');
require('dotenv').config();

// Fetch newly listed tokens with the option to filter by liquidityAddedAt time
const getNewlyListedTokens = async (timeToUnix) => {
    const url = `https://public-api.birdeye.so/defi/v2/tokens/new_listing?time_to=${timeToUnix}&limit=10`; // Add time_to parameter
    try {
        const response = await axios.get(url, {
            headers: {
                'X-API-KEY': process.env.BIRDEYE_API_KEY,  // API Key from .env file
                'accept': 'application/json',
                'x-chain': 'solana'  // Set the chain to 'solana' or other supported chain
            }
        });

        if (response.data && response.data.success && response.data.data && response.data.data.items) {
            console.log("[INFO] New tokens fetched from API:", response.data.data.items);
            return response.data.data.items;  // Return the array of new tokens
        } else {
            console.log("[INFO] No new tokens in the API response.");
            return [];
        }
    } catch (error) {
        console.error("[ERROR] Error fetching newly listed tokens:", error.message);
        return [];
    }
};

// Fetch token security info
const getTokenSecurityInfo = async (tokenAddress) => {
    const url = `https://public-api.birdeye.so/defi/token_security?address=${tokenAddress}`;
    try {
        const response = await axios.get(url, {
            headers: {
                'X-API-KEY': process.env.BIRDEYE_API_KEY,
                'accept': 'application/json',
                'x-chain': 'solana'
            }
        });

        if (response.data && response.data.success && response.data.data) {
            console.log(`Security info for token ${tokenAddress}:`, response.data.data);
            return response.data.data;
        } else {
            console.log(`No security info found for token ${tokenAddress}.`);
            return null;
        }
    } catch (error) {
        console.error(`Error fetching security info for token ${tokenAddress}:`, error.message);
        return null;
    }
};

// Fetch token overview
const getTokenOverview = async (tokenAddress) => {
    const url = `https://public-api.birdeye.so/defi/token_overview?address=${tokenAddress}`;
    try {
        const response = await axios.get(url, {
            headers: {
                'X-API-KEY': process.env.BIRDEYE_API_KEY,
                'accept': 'application/json',
                'x-chain': 'solana'
            }
        });
        
        if (response.data && response.data.success && response.data.data) {
            console.log(`Overview data for token ${tokenAddress}:`, response.data.data);
            return response.data.data;
        } else {
            console.log(`No overview info found for token ${tokenAddress}.`);
            return null;
        }
    } catch (error) {
        console.error(`Error fetching token overview for ${tokenAddress}:`, error.message);
        return null;
    }
};

// Export all necessary functions
module.exports = { getNewlyListedTokens, getTokenSecurityInfo, getTokenOverview };
