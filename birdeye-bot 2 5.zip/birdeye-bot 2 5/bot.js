const { getNewlyListedTokens } = require('./birdeyeApi');
const { filterTokensBySecurity } = require('./utils');
const { trackTokenData } = require('./tracker');
require('dotenv').config();

// Helper function to throttle the polling rate
const throttle = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Get the current Unix timestamp and subtract 3 minutes for latency tolerance
const BOT_START_TIME_UNIX = Math.floor(Date.now() / 1000) - 180;  // 3-minute buffer for potential latency
console.log('[INFO] Bot started at Unix timestamp:', BOT_START_TIME_UNIX);

// Maximum time threshold for tracking (30 seconds from liquidityAddedAt time)
const TOKEN_CREATION_THRESHOLD_SECONDS = 30;

const main = async () => {
    const recordDuration = parseInt(process.env.RECORD_DURATION_MINUTES || '10');
    const recordInterval = parseInt(process.env.RECORD_INTERVAL_MINUTES || '1');
    const trackVolume = process.env.TRACK_VOLUME === 'true';
    const checkSocialMedia = process.env.CHECK_SOCIAL_MEDIA === 'true';
    const pollingInterval = 5000; // 5 seconds throttle

    console.log("[INFO] Starting continuous token scanning...");

    while (true) {
        try {
            console.log(`\n[INFO] Fetching newly listed tokens at ${new Date().toISOString()}`);

            // Fetch newly listed tokens using the time_to parameter for filtering by liquidityAddedAt
            const tokens = await getNewlyListedTokens(BOT_START_TIME_UNIX);

            if (!tokens || tokens.length === 0) {
                console.log("[INFO] No new tokens returned from API.");
            } else {
                console.log("[INFO] Raw tokens response:", tokens);

                const secureTokens = await filterTokensBySecurity(tokens);

                for (const token of secureTokens) {
                    if (!token.address || token.address === 'null' || token.symbol === 'null') {
                        console.log(`[INFO] Skipping token with missing or invalid address or symbol: ${token.address || 'unknown'}`);
                        continue;
                    }

                    const liquidityAddedTimeUnix = token.liquidityAddedAt;

                    // Calculate time difference in seconds between liquidity added time and bot start time
                    const timeDifferenceInSeconds = liquidityAddedTimeUnix - BOT_START_TIME_UNIX;

                    if (timeDifferenceInSeconds > 0 && timeDifferenceInSeconds <= TOKEN_CREATION_THRESHOLD_SECONDS) {
                        console.log(`[INFO] Tracking data for token: ${token.symbol || 'unknown'} (${token.address})`);

                        // Track token data for the specified duration
                        await trackTokenData(token.address, recordDuration, recordInterval, trackVolume);

                        // Check social media presence if enabled
                        if (checkSocialMedia) {
                            if (token.extensions) {
                                const socials = {
                                    website: token.extensions.website || 'N/A',
                                    twitter: token.extensions.twitter || 'N/A',
                                    telegram: token.extensions.telegram || 'N/A',
                                    discord: token.extensions.discord || 'N/A',
                                };
                                console.log(`[INFO] Socials for token ${token.symbol}:`, socials);
                            } else {
                                console.log(`[INFO] No social media information for token ${token.symbol}`);
                            }
                        }
                    } else {
                        console.log(`[INFO] Skipping token ${token.symbol || 'unknown'} (${token.address}) as it does not meet the time criteria.`);
                    }
                }
            }

            await throttle(pollingInterval);

        } catch (error) {
            console.error("[ERROR] Error occurred during token tracking:", error.message);
            await throttle(pollingInterval);
        }
    }
};

main();
