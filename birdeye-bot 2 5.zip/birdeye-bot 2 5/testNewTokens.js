const { getNewlyListedTokens } = require('./birdeyeApi');
require('dotenv').config();

(async () => {
    console.log("Starting token fetch...");

    try {
        const tokens = await getNewlyListedTokens();
        if (tokens && tokens.length > 0) {
            console.log("Fetched tokens:", tokens);
        } else {
            console.log("No tokens fetched or invalid data structure.");
        }
    } catch (error) {
        console.error("An error occurred while fetching tokens:", error);
    }
})();
