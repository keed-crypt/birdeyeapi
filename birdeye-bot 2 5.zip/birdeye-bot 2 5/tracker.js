const fs = require('fs');
const path = require('path');
const { parse } = require('json2csv');
const fetch = require('node-fetch');
const dotenv = require('dotenv');

// Load environment variables from .env file
dotenv.config();

const apiKey = process.env.BIRDEYE_API_KEY;
const recordDuration = parseInt(process.env.RECORD_DURATION_MINUTES, 10) || 10;
const recordInterval = parseInt(process.env.RECORD_INTERVAL_MINUTES, 10) || 1;
const csvFileName = process.env.CSV_FILE_NAME || 'data.csv';

// Function to write data to a CSV file
const writeToCsv = (tokenData, tokenName, tokenSymbol, tokenAddress, socials) => {
    const filePath = path.join(process.cwd(), csvFileName);
    const csvFields = ['tokenName', 'tokenSymbol', 'tokenAddress', 'timeRecorded', 'volume', 'priceChangePercent', 'pnlPercent', 'website', 'twitter', 'discord'];
    const opts = { fields: csvFields, header: false };

    const csvData = {
        tokenName: tokenName || 'Unknown Token',
        tokenSymbol: tokenSymbol || 'Unknown Symbol',
        tokenAddress: tokenAddress || 'N/A',  // Ensure tokenAddress is written
        timeRecorded: new Date().toISOString(),
        volume: tokenData.volume || 0,
        priceChangePercent: tokenData.priceChangePercent || 0,
        pnlPercent: tokenData.pnlPercent || 0,
        website: socials.website || 'N/A',
        twitter: socials.twitter || 'N/A',
        discord: socials.discord || 'N/A',
    };

    try {
        if (!fs.existsSync(filePath)) {
            const csvHeader = parse([], { fields: csvFields, header: true });
            fs.writeFileSync(filePath, csvHeader + '\n', 'utf8');
        }

        const separator = '\n\n'; // Double newline for clarity between different tokens
        const csv = parse([csvData], opts);
        fs.appendFileSync(filePath, separator + csv + '\n', 'utf8');
        console.log(`[INFO] Data for token ${csvData.tokenName} (${csvData.tokenSymbol} - ${csvData.tokenAddress}) written to CSV.`);
    } catch (err) {
        console.error('[ERROR] Writing to CSV failed:', err);
    }
};

// Function to fetch token overview from Birdeye API, including social media details
const fetchTokenOverview = async (tokenAddress) => {
    const url = `https://public-api.birdeye.so/defi/token_overview?address=${tokenAddress}`;
    const options = {
        method: 'GET',
        headers: {
            accept: 'application/json',
            'X-API-KEY': apiKey
        },
    };

    try {
        const response = await fetch(url, options);
        const data = await response.json();

        if (data && data.data) {
            const extensions = data.data.extensions || {};
            return {
                price: data.data.price || 0,
                volume: data.data.volumeUSD || 0,
                symbol: data.data.symbol || 'Unknown',
                name: data.data.name || 'Unknown',
                tokenAddress: tokenAddress,
                socials: {
                    website: extensions.website || null,
                    twitter: extensions.twitter || null,
                    discord: extensions.discord || null,
                }
            };
        }

        return null;
    } catch (err) {
        console.error('[ERROR] Fetching token overview from Birdeye API failed:', err);
        return null;
    }
};

// Function to track token data for a specified duration
const trackTokenData = async (tokenAddress) => {
    const tokenOverview = await fetchTokenOverview(tokenAddress);

    // Skip logging for tokens with 'Unknown', 'null' name or symbol
    if (tokenOverview.name === 'Unknown' || tokenOverview.symbol === 'Unknown' || tokenOverview.name === 'null' || tokenOverview.symbol === 'null') {
        console.log(`[INFO] Skipping token with 'Unknown' or 'null' name or symbol: ${tokenAddress}`);
        return;
    }

    const initialPrice = tokenOverview.price;
    console.log(`[INFO] Started tracking token: ${tokenOverview.name} (${tokenOverview.symbol} - ${tokenAddress}) for ${recordDuration} minutes with ${recordInterval}-minute intervals.`);

    const intervalCount = recordDuration / recordInterval;
    for (let i = 0; i < intervalCount; i++) {
        const currentData = await fetchTokenOverview(tokenAddress);

        if (currentData) {
            const priceChangePercent = ((currentData.price - initialPrice) / initialPrice) * 100;
            const pnlPercent = priceChangePercent; // Assuming PnL is the same as price change percent here

            currentData.priceChangePercent = priceChangePercent;
            currentData.pnlPercent = pnlPercent;

            writeToCsv(currentData, currentData.name, currentData.symbol, tokenAddress, currentData.socials); // Include social media data
        }

        await new Promise((resolve) => setTimeout(resolve, recordInterval * 60 * 1000)); // Convert minutes to milliseconds
    }

    console.log(`[INFO] Finished tracking token: ${tokenOverview.name} (${tokenOverview.symbol} - ${tokenAddress})`);
};

module.exports = { writeToCsv, trackTokenData };
